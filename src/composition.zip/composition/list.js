import React from 'react';
import Card from './card.js';
import './list.css';

function List(header, cards) {
    let mappedCards = cards.map(item => Card(item.title, item.content))
    mappedCards.join('');
    return (
        <div className="App-list">
        <section className="List">
          <header className="List-header">
            <h2>{header}</h2>
          </header>
          <div className="List-cards">
          {mappedCards}
          </div>
        </section>
        </div>
    );
  }

export default List;